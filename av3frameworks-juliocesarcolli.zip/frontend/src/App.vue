<template>
  <v-app>
    <div v-if="!authStore.isInitialized" class="loading-container">
      <v-progress-circular
        indeterminate
        color="primary"
        size="64"
      ></v-progress-circular>
      <p class="mt-4">Verificando autenticação...</p>
    </div>

    <template v-else>
      <v-app-bar color="primary" prominent v-if="authStore.isAuthenticated">
        <v-app-bar-title class="font-weight-bold">
          <v-icon icon="mdi-folder" class="mr-2"></v-icon>
          ProjectFlow
        </v-app-bar-title>
        
        <v-spacer></v-spacer>

        <v-menu location="bottom end">
          <template v-slot:activator="{ props }">
            <v-btn v-bind="props" variant="text" class="text-capitalize">
              <v-avatar size="32" class="mr-2">
                <v-img :src="authStore.user?.photo" />
              </v-avatar>
              {{ getUserFirstName }}
            </v-btn>
          </template>
          <v-card width="200">
            <v-list density="compact">
              <v-list-item>
                <v-list-item-title class="font-weight-bold">{{ authStore.user?.name }}</v-list-item-title>
                <v-list-item-subtitle>{{ authStore.user?.email }}</v-list-item-subtitle>
              </v-list-item>
              <v-divider class="my-1"></v-divider>
              <v-list-item @click="logout" color="error">
                <template v-slot:prepend>
                  <v-icon>mdi-logout</v-icon>
                </template>
                <v-list-item-title>Sair</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-card>
        </v-menu>
      </v-app-bar>

      <v-navigation-drawer v-if="authStore.isAuthenticated" permanent>
        <v-list density="compact" nav class="py-4">
          <v-list-item
            prepend-icon="mdi-view-dashboard" 
            title="Dashboard" 
            value="dashboard"
            @click="$router.push('/')"
            :active="$route.path === '/'"
          ></v-list-item>
          <v-list-item 
            prepend-icon="mdi-folder" 
            title="Projetos" 
            value="projects"
            @click="$router.push('/projects')"
            :active="$route.path.includes('/projects')"
          ></v-list-item>
        </v-list>
      </v-navigation-drawer>

      <v-main>
        <v-container fluid class="pa-4">
          <router-view></router-view>
        </v-container>
      </v-main>
    </template>
  </v-app>
</template>

<script setup>
import { computed, onMounted, watch } from 'vue'
import { useAuthStore } from './stores/auth'
import { useRouter, useRoute } from 'vue-router'

const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()

const getUserFirstName = computed(() => {
  return authStore.user?.name?.split(' ')[0] || 'Usuário'
})

const logout = () => {
  authStore.logout()
}

watch(() => authStore.isAuthenticated, (isAuthenticated) => {
  if (!isAuthenticated && route.meta.requiresAuth) {
    router.push('/login')
  }
})

watch(() => authStore.isAuthenticated, (isAuthenticated) => {
  if (isAuthenticated && route.path === '/login') {
    router.push('/')
  }
})

onMounted(() => {
  authStore.initialize()
})
</script>

<style scoped>
.loading-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
}

.v-list-item--active {
  background-color: rgba(0, 0, 0, 0.08);
  border-radius: 4px;
}
</style>