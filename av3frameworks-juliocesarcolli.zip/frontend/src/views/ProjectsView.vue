<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <v-card>
          <v-card-title class="d-flex justify-space-between align-center">
            <span class="text-h5">Projetos</span>
            <v-btn color="primary" @click="$router.push('/projects/new')" prepend-icon="mdi-plus">
              Novo Projeto
            </v-btn>
          </v-card-title>
          
          <v-card-text>
            <div v-if="loading" class="text-center py-8">
              <v-progress-circular
                indeterminate
                color="primary"
                size="64"
                class="mb-4"
              ></v-progress-circular>
              <p class="text-body-1">Carregando projetos...</p>
            </div>

            <template v-else>
              <v-table v-if="projects.length > 0">
                <thead>
                  <tr>
                    <th>Título</th>
                    <th>Status</th>
                    <th>Prioridade</th>
                    <th>Prazo</th>
                    <th class="text-center">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="project in projects" :key="project.id">
                    <td>
                      <strong>{{ project.title }}</strong>
                      <div class="text-caption text-medium-emphasis">
                        {{ project.description ? project.description.substring(0, 60) + '...' : 'Sem descrição' }}
                      </div>
                    </td>
                    <td>
                      <v-chip :color="getStatusColor(project.status)" size="small">
                        {{ getStatusText(project.status) }}
                      </v-chip>
                    </td>
                    <td>{{ getPriorityText(project.priority) }}</td>
                    <td>{{ formatDate(project.deadline) }}</td>
                    <td class="text-center">
                      <v-tooltip text="Editar" location="top">
                        <template v-slot:activator="{ props }">
                          <v-btn 
                            v-bind="props"
                            icon 
                            size="small" 
                            @click="editProject(project.id)"
                            color="primary"
                            class="mx-1"
                            variant="tonal"
                          >
                            <v-icon>mdi-pencil</v-icon>
                          </v-btn>
                        </template>
                      </v-tooltip>
                      
                      <v-tooltip text="Excluir" location="top">
                        <template v-slot:activator="{ props }">
                          <v-btn 
                            v-bind="props"
                            icon 
                            size="small" 
                            @click="openDeleteDialog(project)"
                            color="error"
                            class="mx-1"
                            variant="tonal"
                          >
                            <v-icon>mdi-delete</v-icon>
                          </v-btn>
                        </template>
                      </v-tooltip>
                    </td>
                  </tr>
                </tbody>
              </v-table>

              <div v-else class="text-center py-8">
                <v-icon size="64" color="grey-lighten-2" class="mb-4">mdi-folder-off-outline</v-icon>
                <h3 class="text-h6 mb-2">Nenhum projeto encontrado</h3>
                <p class="text-body-2 text-medium-emphasis mb-4">
                  Comece criando seu primeiro projeto
                </p>
                <v-btn color="primary" @click="$router.push('/projects/new')" prepend-icon="mdi-plus">
                  Criar Primeiro Projeto
                </v-btn>
              </div>
            </template>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-dialog v-model="deleteDialog" max-width="500">
      <v-card>
        <v-card-title class="d-flex align-center">
          <v-icon icon="mdi-alert-circle" color="warning" class="mr-2"></v-icon>
          Confirmar Exclusão
        </v-card-title>
        
        <v-card-text class="pt-4">
          <p class="text-body-1">
            Tem certeza que deseja excluir o projeto 
            <strong class="error--text">"{{ projectToDelete?.title }}"</strong>?
          </p>
          <p class="text-caption text-medium-emphasis mt-2">
            Esta ação não pode ser desfeita. Todos os dados deste projeto serão permanentemente removidos.
          </p>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn 
            @click="closeDeleteDialog" 
            variant="outlined"
            :disabled="deleteLoading"
          >
            Cancelar
          </v-btn>
          <v-btn 
            color="error" 
            @click="confirmDelete" 
            :loading="deleteLoading"
            prepend-icon="mdi-delete"
          >
            Excluir Projeto
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar.show" :color="snackbar.color" timeout="4000">
      <div class="d-flex align-center">
        <v-icon class="mr-2">{{ snackbar.icon }}</v-icon>
        {{ snackbar.message }}
      </div>
      <template v-slot:actions>
        <v-btn icon @click="snackbar.show = false" variant="text">
          <v-icon>mdi-close</v-icon>
        </v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../services/api'

const router = useRouter()
const projects = ref([])
const loading = ref(true)
const deleteDialog = ref(false)
const projectToDelete = ref(null)
const deleteLoading = ref(false)

const snackbar = ref({
  show: false,
  message: '',
  color: 'success',
  icon: 'mdi-check'
})

const openDeleteDialog = (project) => {
  projectToDelete.value = project
  deleteDialog.value = true
}

const closeDeleteDialog = () => {
  deleteDialog.value = false
  setTimeout(() => {
    projectToDelete.value = null
  }, 300)
}

const confirmDelete = async () => {
  if (!projectToDelete.value) return

  deleteLoading.value = true
  try {
    await api.delete(`/projects/${projectToDelete.value.id}`)
    
    projects.value = projects.value.filter(p => p.id !== projectToDelete.value.id)

    closeDeleteDialog()
    
    showSnackbar('Projeto excluído com sucesso!', 'success', 'mdi-check-circle')
    
  } catch (error) {
    console.error('Erro ao excluir projeto:', error)
    showSnackbar('Erro ao excluir projeto', 'error', 'mdi-alert-circle')
  } finally {
    deleteLoading.value = false
  }
}

const showSnackbar = (message, color, icon) => {
  snackbar.value = {
    show: true,
    message,
    color,
    icon
  }
}

const getStatusColor = (status) => {
  const colors = {
    'pendente': 'warning',
    'em_andamento': 'primary',
    'concluido': 'success',
    'cancelado': 'error'
  }
  return colors[status] || 'default'
}

const getStatusText = (status) => {
  const statusMap = {
    'pendente': 'Pendente',
    'em_andamento': 'Em Andamento',
    'concluido': 'Concluído',
    'cancelado': 'Cancelado'
  }
  return statusMap[status] || status
}

const getPriorityText = (priority) => {
  const priorityMap = {
    'baixa': 'Baixa',
    'media': 'Média',
    'alta': 'Alta',
    'urgente': 'Urgente'
  }
  return priorityMap[priority] || priority
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('pt-BR')
}

const editProject = (id) => {
  router.push(`/projects/edit/${id}`)
}

const loadProjects = async () => {
  loading.value = true
  try {
    projects.value = await api.get('/projects')
  } catch (error) {
    console.error('Erro ao carregar projetos:', error)
    showSnackbar('Erro ao carregar projetos', 'error', 'mdi-alert-circle')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadProjects()
})
</script>

<style scoped>
.v-dialog {
  transition: all 0.3s ease;
}

.v-btn {
  min-width: 36px !important;
  height: 36px !important;
}

.v-btn--icon {
  border-radius: 8px;
}

.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}
</style>