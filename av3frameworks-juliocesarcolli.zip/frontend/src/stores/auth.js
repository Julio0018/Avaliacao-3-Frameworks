import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { supabase } from '../services/supabase'
import { useRouter } from 'vue-router'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const isLoading = ref(false)
  const isInitialized = ref(false)
  const isAuthenticated = computed(() => !!user.value)
  const router = useRouter()

  async function login() {
    try {
      isLoading.value = true
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`
        }
      })
      
      if (error) throw error
    } 
    
      catch (error) {
        console.error('Erro no login:', error)
        throw error
    } 
    
      finally {
        isLoading.value = false
    }
  }

  async function handleAuthCallback() {
    try {
      const { data: { session }, error } = await supabase.auth.getSession()
      
      if (error) throw error
      
      if (session?.user) {
        user.value = {
          name: session.user.user_metadata.full_name || session.user.email,
          email: session.user.email,
          photo: session.user.user_metadata.avatar_url,
          uid: session.user.id
        }
        
        localStorage.setItem('supabase_token', session.access_token)
        return true
      }
      return false
    } 
    
      catch (error) {
        console.error('Erro no callback de autenticação:', error)
      return false
    }
  }

  async function logout() {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) throw error
      
      user.value = null
      localStorage.removeItem('supabase_token')
      localStorage.removeItem('supabase_user')
      router.push('/login')
    } 
      
      catch (error) {
        console.error('Erro no logout:', error)
      throw error
    }
  }

  async function checkAuth() {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      
      if (session?.user) {
        user.value = {
          name: session.user.user_metadata.full_name || session.user.email,
          email: session.user.email,
          photo: session.user.user_metadata.avatar_url,
          uid: session.user.id
        }
        localStorage.setItem('supabase_token', session.access_token)
        localStorage.setItem('supabase_user', JSON.stringify(user.value))
      } 
      
        else {
          const savedUser = localStorage.getItem('supabase_user')
          const savedToken = localStorage.getItem('supabase_token')
        
        if (savedUser && savedToken) {
          user.value = JSON.parse(savedUser)
          console.log('Usuário restaurado do localStorage')
        } 
        
          else {
            user.value = null
        }
      }
    } 
    
      catch (error) {
        console.error('Erro ao verificar autenticação:', error)
        const savedUser = localStorage.getItem('supabase_user')
        const savedToken = localStorage.getItem('supabase_token')
      
      if (savedUser && savedToken) {
        user.value = JSON.parse(savedUser)
        console.log('Usuário restaurado do localStorage após erro')
      } 
      
        else {
          user.value = null
      }
    }
  }

  function initialize() {
    isInitialized.value = false
    
    checkAuth().finally(() => {
      isInitialized.value = true
    })

    supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event)
      
      if (event === 'SIGNED_IN' && session) {
        user.value = {
          name: session.user.user_metadata.full_name || session.user.email,
          email: session.user.email,
          photo: session.user.user_metadata.avatar_url,
          uid: session.user.id
        }
        
        localStorage.setItem('supabase_token', session.access_token)
        localStorage.setItem('supabase_user', JSON.stringify(user.value))
        
        if (router.currentRoute.value.path === '/login') {
          router.push('/')
        }
      } 
      
        else if (event === 'SIGNED_OUT') {
          user.value = null
          localStorage.removeItem('supabase_token')
          localStorage.removeItem('supabase_user')
          router.push('/login')
      } 
      
        else if (event === 'TOKEN_REFRESHED') {
          if (session) {
            localStorage.setItem('supabase_token', session.access_token)
        }
      }
    })
  }

  function getToken() {
    return localStorage.getItem('supabase_token')
  }

  return { 
    user, 
    isAuthenticated, 
    isLoading,
    isInitialized: computed(() => isInitialized.value),
    login, 
    logout, 
    initialize, 
    checkAuth,
    getToken,
    handleAuthCallback
  }
})