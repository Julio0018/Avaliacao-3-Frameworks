<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="10" md="8" lg="6">
        <v-card class="pa-6" elevation="4">
          <div class="text-center mb-6">
            <v-icon 
              size="64" 
              color="primary" 
              class="mb-4"
            >
              mdi-folder-multiple
            </v-icon>
            <h1 class="text-h3 font-weight-bold primary--text mb-2">
              ProjectFlow
            </h1>
            <p class="text-subtitle-1 text-medium-emphasis">
              Sistema de Gestão de Projetos
            </p>
          </div>

          <v-divider class="my-4"></v-divider>

          <v-card-text class="text-center px-8">
            <div class="mb-8">
              <v-icon size="48" color="green" class="mb-2">
                mdi-shield-check
              </v-icon>
              <h2 class="text-h5 mb-2">
                Bem-vindo de volta!
              </h2>
              <p class="text-body-1 text-medium-emphasis">
                Gerencie seus projetos de forma simples e eficiente.<br>
                Faça login para continuar.
              </p>
            </div>

            <v-btn 
              color="primary" 
              size="x-large" 
              @click="signInWithGoogle"
              :loading="authStore.isLoading"
              class="mb-6"
              block
              height="56"
            >
              <v-icon left size="24">
                mdi-google
              </v-icon>
              <span class="font-weight-bold">
                Entrar com Google
              </span>
            </v-btn>

            <v-alert 
              type="info" 
              variant="tonal" 
              density="compact"
              class="mb-4"
            >
              <div class="d-flex align-center">
                <v-icon size="20" class="mr-2">mdi-information</v-icon>
                <span class="text-caption">
                  Suas informações estão protegidas. Usamos autenticação segura do Google.
                </span>
              </div>
            </v-alert>
 
            <div v-if="error" class="mt-4">
              <v-alert 
                type="error" 
                density="compact"
                class="text-left"
              >
                <div class="d-flex align-center">
                  <v-icon size="20" class="mr-2">mdi-alert-circle</v-icon>
                  <span>{{ error }}</span>
                </div>
              </v-alert>
            </div>

            <div class="mt-8 pt-4 text-center">
              <p class="text-caption text-disabled">
                <v-icon size="16" class="mr-1">mdi-lock</v-icon>
                © 2024 ProjectFlow - Todos os direitos reservados
              </p>
            </div>
          </v-card-text>
        </v-card>

        <v-row class="mt-8" v-if="$vuetify.display.mdAndUp">
          <v-col cols="4" v-for="(feature, index) in features" :key="index">
            <v-card variant="tonal" class="pa-4 text-center">
              <v-icon size="40" :color="feature.color" class="mb-3">
                {{ feature.icon }}
              </v-icon>
              <h4 class="text-h6 mb-2">{{ feature.title }}</h4>
              <p class="text-caption text-medium-emphasis">
                {{ feature.description }}
              </p>
            </v-card>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'

const authStore = useAuthStore()
const router = useRouter()
const error = ref('')

const features = [
  {
    icon: 'mdi-chart-timeline-variant',
    title: 'Dashboard Inteligente',
    description: 'Acompanhe o progresso dos seus projetos',
    color: 'blue'
  },
  {
    icon: 'mdi-calendar-check',
    title: 'Gestão de Prazos',
    description: 'Controle datas e deadlines importantes',
    color: 'green'
  },
  {
    icon: 'mdi-account-group',
    title: 'Colaboração',
    description: 'Trabalhe em equipe de forma eficiente',
    color: 'orange'
  }
]

watch(() => authStore.isAuthenticated, (isAuthenticated) => {
  if (isAuthenticated) {
    router.push('/')
  }
})

onMounted(() => {
  if (authStore.isAuthenticated) {
    router.push('/')
  }
})

const signInWithGoogle = async () => {
  try {
    error.value = ''
    await authStore.login()
  } catch (err) {
    error.value = 'Erro ao fazer login. Tente novamente.'
    console.error('Erro no login:', err)
  }
}
</script>

<style scoped>
.v-card {
  border-radius: 16px;
  overflow: hidden;
}

.v-btn {
  border-radius: 12px;
  text-transform: none;
  letter-spacing: normal;
  font-size: 1rem;
}

.v-btn:hover {
  transform: translateY(-2px);
  transition: transform 0.2s ease;
}

.v-card {
  animation: fadeIn 0.6s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.v-container.fill-height {
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}
</style>