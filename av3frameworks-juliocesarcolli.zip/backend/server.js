import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import swaggerDocs from './swagger.js';

dotenv.config();

console.log('=== CONFIGURAÇÃO DO BACKEND ===');
console.log('SUPABASE_URL:', process.env.SUPABASE_URL || 'NÃO CONFIGURADO');
console.log('SERVICE_KEY:', process.env.SUPABASE_SERVICE_KEY ? 'CONFIGURADO' : 'NÃO CONFIGURADO');
console.log('PORT:', process.env.PORT || 3000);
console.log('================================');

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
  console.error('ERRO CRÍTICO: Variáveis de ambiente não configuradas!');
  console.log('Por favor, verifique o arquivo .env na pasta backend/');
  console.log('O arquivo deve conter:');
  console.log('SUPABASE_URL=https://zhcnfdjwjbdkjojuivxb.supabase.co');
  console.log('SUPABASE_SERVICE_KEY=sua_chave_service_role_aqui');
  process.exit(1);
}

import { createClient } from '@supabase/supabase-js';
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

console.log('Cliente Supabase criado com sucesso');

import projectRoutes from './src/routes/projects.js';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/projects', (req, res, next) => {
  req.supabase = supabase;
  next();
}, projectRoutes);

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'ProjectFlow API is running',
    timestamp: new Date().toISOString()
  });
});

app.get('/api/test-supabase', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('projects')
      .select('count')
      .limit(1);
    
    if (error) throw error;
    
    res.json({ 
      supabase_status: 'CONECTADO',
      database_status: 'ACESSÍVEL',
      data: data 
    });
  } catch (error) {
    res.status(500).json({ 
      supabase_status: 'ERRO',
      error: error.message 
    });
  }
});

swaggerDocs(app, PORT);

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
  console.log(`Health: http://localhost:${PORT}/api/health`);
  console.log(`Teste Supabase: http://localhost:${PORT}/api/test-supabase`);
  console.log(`Swagger Docs: http://localhost:${PORT}/api-docs`);
});